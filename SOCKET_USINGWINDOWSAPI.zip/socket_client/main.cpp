#include<WINSOCK2.H>
#include<STDIO.H>
#include<iostream>
#include<cstring>
using namespace std;
#pragma comment(lib, "ws2_32.lib")

int main()
{
	WORD sockVersion = MAKEWORD(2, 2);
	//返回值：一个无符号16位整形数.就是定义一个字长
	WSADATA data;
	//这个结构被用来存储被WSAStartup函数调用后返回的Windows Sockets数据。它包含Winsock.dll执行的数据。
	if(WSAStartup(sockVersion, &data)!=0)
	{
		return 0;
	}
	// wVersionRequested：一个WORD（双字节）型数值，在最高版本的Windows Sockets支持调用者使用，高阶字节指定小版本(修订本)号,低位字节指定主版本号。
        //⑵lpWSAData 指向WSADATA数据结构的指针，用来接收Windows Sockets [1]  实现的细节。
	while(true){
		SOCKET sclient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		/*
		*domain -- 指明使用的协议族。常用的协议族有，AF_INET、AF_INET6、AF_LOCAL（或称AF_UNIX，Unix域socket）、AF_ROUTE等等。协议族决定了socket的地址类型，
		*在通信中必须采用对应的地址，如AF_INET决定了要用ipv4地址（32位的）与端口号（16位的）的组合、AF_UNIX决定了要用一个绝对路径名作为地址。
                *type -- 指明socket类型，有3种：
                *SOCK_STREAM -- TCP类型，保证数据顺序及可靠性；
                *SOCK_DGRAM --  UDP类型，不保证数据接收的顺序，非可靠连接；
                *SOCK_RAW -- 原始类型，允许对底层协议如IP或ICMP进行直接访问，不太常用。
                *protocol -- 通常赋值"0"，由系统自动选择。
                */
		if(sclient == INVALID_SOCKET)
		{
			printf("invalid socket!");
			return 0;
		}

		sockaddr_in serAddr;
		serAddr.sin_family = AF_INET;
		serAddr.sin_port = htons(8888);
		serAddr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
		if(connect(sclient, (sockaddr *)&serAddr, sizeof(serAddr)) == SOCKET_ERROR)
		{  //连接失败
			printf("connect error !");
			closesocket(sclient);
			return 0;
		}

		string data;
		cin>>data;
		const char * sendData;
		sendData = data.c_str();   //string转const char*
		//char * sendData = "你好，TCP服务端，我是客户端\n";
		send(sclient, sendData, strlen(sendData), 0);
		//send()用来将数据由指定的socket传给对方主机
		//int send(int s, const void * msg, int len, unsigned int flags)
		//s为已建立好连接的socket，msg指向数据内容，len则为数据长度，参数flags一般设0
		//成功则返回实际传送出去的字符数，失败返回-1，错误原因存于error

		char recData[255];
		int ret = recv(sclient, recData, 255, 0);
		if(ret>0){
			recData[ret] = 0x00;
			printf(recData);
		}
		closesocket(sclient);
	}


	WSACleanup();
	return 0;

}

