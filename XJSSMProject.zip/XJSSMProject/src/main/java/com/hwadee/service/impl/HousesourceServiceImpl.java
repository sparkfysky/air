package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.HousesourceMapper;
import com.hwadee.entity.Housesource;
import com.hwadee.service.HousesourceService;

@Service
public class HousesourceServiceImpl implements HousesourceService {
		@Autowired
		private HousesourceMapper HousesourceMapper;

		/*
		 * 保存用户信息
		 */
		public int addHousesource(Housesource user) {
			//调用数据处理层
			return HousesourceMapper.insert(user);
		}
		
		public int deleteHousesource(int employeeid) {
			return HousesourceMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateHousesource(Housesource user) {
			return HousesourceMapper.updateByPrimaryKey(user);
	}
		
		public Housesource getHousesourceById(int employeeid) {
			return HousesourceMapper.selectByPrimaryKey(employeeid);
	}
		public List<Housesource> getHousesourceList() 
		{
		    return HousesourceMapper.selectAll();
		}
}