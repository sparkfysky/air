package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.DepartmentMapper;
import com.hwadee.entity.Department;
import com.hwadee.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {
		@Autowired
		private DepartmentMapper operatorMapper;

		/*
		 * 保存用户信息
		 */
		public int addOperator(Department user) {
			//调用数据处理层
			return operatorMapper.insert(user);
		}
		
		public int deleteOperator(int employeeid) {
			return operatorMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateOperator(Department user) {
			return operatorMapper.updateByPrimaryKey(user);
	}
		
		public Department getOperatorById(int employeeid) {
			return operatorMapper.selectByPrimaryKey(employeeid);
	}
		public List<Department> getOperatorList() 
		{
		    return operatorMapper.selectAll();
		}
}