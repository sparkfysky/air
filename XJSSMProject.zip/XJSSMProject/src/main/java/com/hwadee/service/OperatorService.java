package com.hwadee.service;

import com.hwadee.entity.Operator;

import java.util.List;

import com.hwadee.dao.OperatorMapper;

public interface OperatorService {
	int addOperator(Operator model);
	
	int deleteOperator(int employeeid);
	
	Operator getOperatorById(int employeeid);
	
	
	
	List<Operator> getOperatorList();
	
	int updateOperator(Operator model);
	
	
}