package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.GuestacMapper;
import com.hwadee.entity.Guestac;
import com.hwadee.service.GuestacService;

@Service
public class GuestacServiceImpl implements GuestacService {
		@Autowired
		private GuestacMapper guestacMapper;

		/*
		 * 保存用户信息
		 */
		public int addGuestac(Guestac user) {
			//调用数据处理层
			return guestacMapper.insert(user);
		}
		
		public int deleteGuestac(int employeeid) {
			return guestacMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateGuestac(Guestac user) {
			return guestacMapper.updateByPrimaryKey(user);
	}
		
		public Guestac getGuestacById(int employeeid) {
			return guestacMapper.selectByPrimaryKey(employeeid);
	}
		public List<Guestac> getGuestacList() 
		{
		    return guestacMapper.selectAll();
		}
}