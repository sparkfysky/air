package com.hwadee.service;

import com.hwadee.entity.Housemessage;

import java.util.List;

import com.hwadee.dao.HousemessageMapper;

public interface HousemessageService {
	int addHousemessage(Housemessage model);
	
	int deleteHousemessage(int messageid);
	
	Housemessage getHousemessageById(int messageid);
	
	List<Housemessage> getHousemessageList();
	
	int updateHousemessage(Housemessage model);
	
	
}