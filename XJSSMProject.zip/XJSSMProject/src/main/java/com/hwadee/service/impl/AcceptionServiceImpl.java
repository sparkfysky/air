package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.AcceptionMapper;
import com.hwadee.entity.Acception;
import com.hwadee.service.AcceptionService;

@Service
public class AcceptionServiceImpl implements AcceptionService {
		@Autowired
		private AcceptionMapper AcceptionMapper;

		/*
		 * 保存用户信息
		 */
		public int addAcception(Acception user) {
			//调用数据处理层
			return AcceptionMapper.insert(user);
		}
		
		public int deleteAcception(int employeeid) {
			return AcceptionMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateAcception(Acception user) {
			return AcceptionMapper.updateByPrimaryKey(user);
	}
		
		public Acception getAcceptionById(int employeeid) {
			return AcceptionMapper.selectByPrimaryKey(employeeid);
	}
		public List<Acception> getAcceptionList() 
		{
		    return AcceptionMapper.selectAll();
		}
}