package com.hwadee.service;

import com.hwadee.entity.Complain;

import java.util.List;

import com.hwadee.dao.ComplainMapper;

public interface ComplainService {
	int addComplain(Complain model);
	
	int deleteComplain(int complainid);
	
	Complain getComplainById(int complainid);
	
	List<Complain> getComplainList();
	
	int updateComplain(Complain model);
	
	
}