package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.EstateMapper;
import com.hwadee.entity.Estate;
import com.hwadee.service.EstateService;

@Service
public class EstateServiceImpl implements EstateService {
		@Autowired
		private EstateMapper EstateMapper;

		/*
		 * 保存用户信息
		 */
		public int addEstate(Estate user) {
			//调用数据处理层
			return EstateMapper.insert(user);
		}
		
		public int deleteEstate(int employeeid) {
			return EstateMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateEstate(Estate user) {
			return EstateMapper.updateByPrimaryKey(user);
	}
		
		public Estate getEstateById(int employeeid) {
			return EstateMapper.selectByPrimaryKey(employeeid);
	}
		public List<Estate> getEstateList() 
		{
		    return EstateMapper.selectAll();
		}
}