package com.hwadee.service;

import com.hwadee.entity.Housesource;


import java.util.List;

import com.hwadee.dao.HousesourceMapper;

public interface HousesourceService {
	int addHousesource(Housesource model);
	
	int deleteHousesource(int employeeid);
	
	Housesource getHousesourceById(int employeeid);
	
	
	
	List<Housesource> getHousesourceList();
	
	int updateHousesource(Housesource model);
	
	
}