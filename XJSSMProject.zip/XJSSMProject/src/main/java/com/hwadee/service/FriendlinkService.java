package com.hwadee.service;

import com.hwadee.entity.Friendlink;

import java.util.List;

import com.hwadee.dao.FriendlinkMapper;

public interface FriendlinkService {
	int addFriendlink(Friendlink model);
	int deleteFriendlink(int userid);
	Friendlink getFriendlinkById(int userid);
	
	List<Friendlink> getFriendlinkList();
	int updateFriendlink(Friendlink model);
	
	
}