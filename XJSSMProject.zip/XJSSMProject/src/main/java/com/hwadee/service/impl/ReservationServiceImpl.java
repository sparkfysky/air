package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.ReservationMapper;
import com.hwadee.entity.Reservation;
import com.hwadee.service.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService {
		@Autowired
		private ReservationMapper reservationMapper;
		
		public int addReservation(Reservation model) {
			return reservationMapper.insert(model);
		}
		
		public int deleteReservation(int reservationid) {
			return reservationMapper.deleteByPrimaryKey(reservationid);
		}
		
		public int updateReservation(Reservation model) {
			return reservationMapper.updateByPrimaryKey(model);
		}
		
		public Reservation getReservationById(int reservationid) {
			return reservationMapper.selectByPrimaryKey(reservationid);
		}
		
		public List<Reservation> getReservationList() 
		{
		    return reservationMapper.selectAll();
		}
}