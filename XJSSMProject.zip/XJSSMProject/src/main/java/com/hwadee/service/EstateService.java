package com.hwadee.service;

import com.hwadee.entity.Estate;

import java.util.List;

import com.hwadee.dao.EstateMapper;

public interface EstateService {
	int addEstate(Estate model);
	
	int deleteEstate(int employeeid);
	
	Estate getEstateById(int employeeid);
	
	
	
	List<Estate> getEstateList();
	
	int updateEstate(Estate model);
	
	
}