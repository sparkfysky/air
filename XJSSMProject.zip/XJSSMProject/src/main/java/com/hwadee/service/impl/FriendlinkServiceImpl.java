package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.FriendlinkMapper;
import com.hwadee.entity.Friendlink;
import com.hwadee.service.FriendlinkService;

@Service
public class FriendlinkServiceImpl implements FriendlinkService {
		@Autowired
		private FriendlinkMapper myMapper;

		/*
		 * 保存用户信息
		 */
		public int addFriendlink(Friendlink user) {
			//调用数据处理层
			return myMapper.insert(user);
		}
		
		public int deleteFriendlink(int userid) {
			return myMapper.deleteByPrimaryKey(userid);
		}
			
		
		public int updateFriendlink(Friendlink user) {
			return myMapper.updateByPrimaryKey(user);
	}
		
		public Friendlink getFriendlinkById(int userid) {
			return myMapper.selectByPrimaryKey(userid);
	}
		public List<Friendlink> getFriendlinkList() 
		{
		    return myMapper.selectAll();
		}
}