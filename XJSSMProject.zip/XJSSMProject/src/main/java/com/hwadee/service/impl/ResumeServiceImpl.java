package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.ResumeMapper;
import com.hwadee.entity.Resume;
import com.hwadee.service.ResumeService;

@Service
public class ResumeServiceImpl implements ResumeService {
		@Autowired
		private ResumeMapper resumeMapper;
		
		public int addResume(Resume model) {
			return resumeMapper.insert(model);
		}
		
		public int deleteResume(int resumeid) {
			return resumeMapper.deleteByPrimaryKey(resumeid);
		}
		
		public int updateResume(Resume model) {
			return resumeMapper.updateByPrimaryKey(model);
		}
		
		public Resume getResumeById(int resumeid) {
			return resumeMapper.selectByPrimaryKey(resumeid);
		}
		
		public List<Resume> getResumeList() 
		{
		    return resumeMapper.selectAll();
		}
}