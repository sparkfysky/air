package com.hwadee.service;

import com.hwadee.entity.Acception;

import java.util.List;

import com.hwadee.dao.AcceptionMapper;

public interface AcceptionService {
	int addAcception(Acception model);
	
	int deleteAcception(int employeeid);
	
	Acception getAcceptionById(int employeeid);
	
	
	
	List<Acception> getAcceptionList();
	
	int updateAcception(Acception model);
	
	
}