package com.hwadee.service;

import com.hwadee.entity.Department;

import java.util.List;

import com.hwadee.dao.DepartmentMapper;

public interface DepartmentService {
	int addOperator(Department model);
	
	int deleteOperator(int employeeid);
	
	Department getOperatorById(int employeeid);
	
	
	
	List<Department> getOperatorList();
	
	int updateOperator(Department model);
	
	
}