package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.ComplainMapper;
import com.hwadee.entity.Complain;
import com.hwadee.service.ComplainService;

@Service
public class ComplainServiceImpl implements ComplainService {
		@Autowired
		private ComplainMapper complainMapper;
		
		public int addComplain(Complain model) {
			return complainMapper.insert(model);
		}
		
		public int deleteComplain(int complainid) {
			return complainMapper.deleteByPrimaryKey(complainid);
		}
		
		public int updateComplain(Complain model) {
			return complainMapper.updateByPrimaryKey(model);
		}
		
		public Complain getComplainById(int complainid) {
			return complainMapper.selectByPrimaryKey(complainid);
		}
		
		public List<Complain> getComplainList() 
		{
		    return complainMapper.selectAll();
		}
}