package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.HousemessageMapper;
import com.hwadee.entity.Housemessage;
import com.hwadee.service.HousemessageService;

@Service
public class HousemessageServiceImpl implements HousemessageService {
		@Autowired
		private HousemessageMapper housemessageMapper;
		
		public int addHousemessage(Housemessage model) {
			return housemessageMapper.insert(model);
		}
		
		public int deleteHousemessage(int messageid) {
			return housemessageMapper.deleteByPrimaryKey(messageid);
		}
		
		public int updateHousemessage(Housemessage model) {
			return housemessageMapper.updateByPrimaryKey(model);
		}
		
		public Housemessage getHousemessageById(int messageid) {
			return housemessageMapper.selectByPrimaryKey(messageid);
		}
		
		public List<Housemessage> getHousemessageList() 
		{
		    return housemessageMapper.selectAll();
		}
}