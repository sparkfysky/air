package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.OperatorMapper;
import com.hwadee.entity.Operator;
import com.hwadee.service.OperatorService;

@Service
public class OperatorServiceImpl implements OperatorService {
		@Autowired
		private OperatorMapper operatorMapper;

		/*
		 * 保存用户信息
		 */
		public int addOperator(Operator user) {
			//调用数据处理层
			return operatorMapper.insert(user);
		}
		
		public int deleteOperator(int employeeid) {
			return operatorMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateOperator(Operator user) {
			return operatorMapper.updateByPrimaryKey(user);
	}
		
		public Operator getOperatorById(int employeeid) {
			return operatorMapper.selectByPrimaryKey(employeeid);
	}
		public List<Operator> getOperatorList() 
		{
		    return operatorMapper.selectAll();
		}
}