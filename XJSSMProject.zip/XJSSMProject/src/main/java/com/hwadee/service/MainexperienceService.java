package com.hwadee.service;

import com.hwadee.entity.Mainexperience;

import java.util.List;

import com.hwadee.dao.MainexperienceMapper;

public interface MainexperienceService {
	int addMainexperience(Mainexperience model);
	
	int deleteMainexperience(int employeeid);
	
	Mainexperience getMainexperienceById(int employeeid);
	
	
	
	List<Mainexperience> getMainexperienceList();
	
	int updateMainexperience(Mainexperience model);
	
	
}