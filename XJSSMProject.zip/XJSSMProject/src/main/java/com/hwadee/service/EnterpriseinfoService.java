package com.hwadee.service;

import com.hwadee.entity.Enterpriseinfo;

import java.sql.SQLException;
import java.util.List;


public interface EnterpriseinfoService{
	int add(Enterpriseinfo userEntity);
	int del(int hid);
	int upd(Enterpriseinfo userEntity);
	Enterpriseinfo sel(int hid);
    List<Enterpriseinfo> selectenter();
    List<Enterpriseinfo> selecttype(String type);
		// TODO Auto-generated method stub
	//Page<Enterpriseinfo> getPageStudentList(Page<Enterpriseinfo> page);

	
}