package com.hwadee.service;

import com.hwadee.entity.Permission;

import java.util.List;

import com.hwadee.dao.PermissionMapper;

public interface PermissionService {
	int addPermission(Permission model);
	
	int deletePermission(int employeeid);
	
	Permission getPermissionById(int employeeid);
	
	
	
	List<Permission> getPermissionList();
	
	int updatePermission(Permission model);
	
	
}