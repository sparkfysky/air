package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.PermissionMapper;
import com.hwadee.entity.Permission;
import com.hwadee.service.PermissionService;

@Service
public class PermissionServiceImpl implements PermissionService {
		@Autowired
		private PermissionMapper operatorMapper;

		/*
		 * 保存用户信息
		 */
		public int addPermission(Permission user) {
			//调用数据处理层
			return operatorMapper.insert(user);
		}
		
		public int deletePermission(int employeeid) {
			return operatorMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updatePermission(Permission user) {
			return operatorMapper.updateByPrimaryKey(user);
	}
		
		public Permission getPermissionById(int employeeid) {
			return operatorMapper.selectByPrimaryKey(employeeid);
	}
		public List<Permission> getPermissionList() 
		{
		    return operatorMapper.selectAll();
		}
}