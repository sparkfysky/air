package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.UserMapper;
import com.hwadee.entity.User;
import com.hwadee.service.UserService;

/*
 * 用户业务处理实现类
 */

@Service
public class UserServiceImpl implements UserService {
		@Autowired
		private UserMapper userMapper;
		
		/*
		 * 保存用户信息
		 */
		public int add (User user) {
			//调用数据处理层
			return userMapper.insert(user);
		}
		public User selectByPrimaryKey(Integer userid) {
			return userMapper.selectByPrimaryKey(userid);
		
	}
}