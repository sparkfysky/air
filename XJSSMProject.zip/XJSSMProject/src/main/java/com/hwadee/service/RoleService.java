package com.hwadee.service;

import com.hwadee.entity.Role;

import java.util.List;

import com.hwadee.dao.RoleMapper;

public interface RoleService {
	int addRole(Role model);
	
	int deleteRole(int employeeid);
	
	Role getRoleById(int employeeid);
	
	
	
	List<Role> getRoleList();
	
	int updateRole(Role model);
	
	
}