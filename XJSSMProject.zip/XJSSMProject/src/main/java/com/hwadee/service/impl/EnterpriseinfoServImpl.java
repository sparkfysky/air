package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.EnterpriseinfoMapper;
import com.hwadee.entity.Enterpriseinfo;
import com.hwadee.service.EnterpriseinfoService;

/*
 * 用户业务处理实现类
 */

@Service
public class EnterpriseinfoServImpl implements EnterpriseinfoService {
	    @Autowired
	    private EnterpriseinfoMapper enterMapper;
	    
	    
	    public int add (Enterpriseinfo enter)
	    {
	    	return enterMapper.insert(enter);
	    }
	    
	    
	    public int del (int enterid)
	    {
	    	return enterMapper.deleteByPrimaryKey(enterid);
	    }
	    
	    public int upd (Enterpriseinfo enter)
	    {
	    	return enterMapper.updateByPrimaryKey(enter);
	    }
	    
	    public List<Enterpriseinfo> selectenter()
	    {
	    	return enterMapper.selectAll();
	    }
	    
	    public Enterpriseinfo sel (int enterid)
	    {
	    	return enterMapper.selectByPrimaryKey(enterid);
	    }
	    
	    public List<Enterpriseinfo> selecttype(String type)
	    {
	    	return enterMapper.selectByType(type);
	    }
}