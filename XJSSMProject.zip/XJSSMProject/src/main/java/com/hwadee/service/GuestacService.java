package com.hwadee.service;

import com.hwadee.entity.Guestac;

import java.util.List;

import com.hwadee.dao.GuestacMapper;

public interface GuestacService {
	int addGuestac(Guestac model);
	
	int deleteGuestac(int employeeid);
	
	Guestac getGuestacById(int employeeid);
	
	
	
	List<Guestac> getGuestacList();
	
	int updateGuestac(Guestac model);
	
	
}