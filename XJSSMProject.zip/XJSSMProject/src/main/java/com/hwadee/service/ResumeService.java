package com.hwadee.service;

import com.hwadee.entity.Resume;

import java.util.List;

import com.hwadee.dao.ResumeMapper;

public interface ResumeService {
	int addResume(Resume model);
	
	int deleteResume(int resumeid);
	
	Resume getResumeById(int resumeid);
	
	List<Resume> getResumeList();
	
	int updateResume(Resume model);
	
	
}