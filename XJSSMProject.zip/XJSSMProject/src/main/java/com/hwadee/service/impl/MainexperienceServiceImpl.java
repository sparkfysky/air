package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.MainexperienceMapper;
import com.hwadee.entity.Mainexperience;
import com.hwadee.service.MainexperienceService;

@Service
public class MainexperienceServiceImpl implements MainexperienceService {
		@Autowired
		private MainexperienceMapper operatorMapper;

		/*
		 * 保存用户信息
		 */
		public int addMainexperience(Mainexperience user) {
			//调用数据处理层
			return operatorMapper.insert(user);
		}
		
		public int deleteMainexperience(int employeeid) {
			return operatorMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateMainexperience(Mainexperience user) {
			return operatorMapper.updateByPrimaryKey(user);
	}
		
		public Mainexperience getMainexperienceById(int employeeid) {
			return operatorMapper.selectByPrimaryKey(employeeid);
	}
		public List<Mainexperience> getMainexperienceList() 
		{
		    return operatorMapper.selectAll();
		}
}