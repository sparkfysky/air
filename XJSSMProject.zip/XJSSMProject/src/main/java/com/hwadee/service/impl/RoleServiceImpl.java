package com.hwadee.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hwadee.dao.RoleMapper;
import com.hwadee.entity.Role;
import com.hwadee.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {
		@Autowired
		private RoleMapper RoleMapper;

		/*
		 * 保存用户信息
		 */
		public int addRole(Role user) {
			//调用数据处理层
			return RoleMapper.insert(user);
		}
		
		public int deleteRole(int employeeid) {
			return RoleMapper.deleteByPrimaryKey(employeeid);
		}
			
		
		public int updateRole(Role user) {
			return RoleMapper.updateByPrimaryKey(user);
	}
		
		public Role getRoleById(int employeeid) {
			return RoleMapper.selectByPrimaryKey(employeeid);
	}
		public List<Role> getRoleList() 
		{
		    return RoleMapper.selectAll();
		}
}