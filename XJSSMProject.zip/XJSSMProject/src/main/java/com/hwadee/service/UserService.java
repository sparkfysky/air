package com.hwadee.service;

import com.hwadee.entity.User;

import java.sql.SQLException;
import java.util.List;


public interface UserService{
	int add(User userEntity);
	User selectByPrimaryKey(Integer userid);


	
}

