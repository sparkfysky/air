package com.hwadee.service;

import com.hwadee.entity.Reservation;

import java.util.List;

import com.hwadee.dao.ReservationMapper;

public interface ReservationService {
	int addReservation(Reservation model);
	
	int deleteReservation(int reservationid);
	
	Reservation getReservationById(int reservationid);
	
	List<Reservation> getReservationList();
	
	int updateReservation(Reservation model);
	
	
}