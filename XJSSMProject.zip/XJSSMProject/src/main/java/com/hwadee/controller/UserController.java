package com.hwadee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hwadee.entity.User;
import com.hwadee.service.UserService;

@Controller
@RequestMapping("/user1")
public class UserController {
	
	/*
	 * IOC/DI
	 */
	@Autowired
	private UserService userService;

	/*
	 * 访问addUser.jsp页面
	 */
	@RequestMapping("/regist")
	public String visitIndex1() {
		return "user1/index"; // 视图中文件的名称(不带后缀名的)
	}
	/*
	 * 添加信息界面
	 */
		@RequestMapping("/index")
		public String  saveuser(@Valid User userEntity,Model model) {
			int flag = userService.add(userEntity);
			return "user1/login";
		}
		/*
		 * 添加信息界面
		 */
		
		/*
		 * 访问addUser.jsp页面
		 */
		@RequestMapping("/log")
		public String visitIndex2() {
			return "user1/login"; // 视图中文件的名称(不带后缀名的)
		}
		
		
			@RequestMapping("/loginw")
			public String  checklog(@Valid Integer userid,String email){
				User userEntity =userService.selectByPrimaryKey(userid);
				if(userEntity == null) {
					return "user1/login";
				}
				String pass=userEntity.getUserpassword();
				if(pass.equals(email)) {
					return "houtai";
				} else {
					return "user1/login";
				}
			}
		
			
		
		
		
	
	}
	
	



	
	

	

