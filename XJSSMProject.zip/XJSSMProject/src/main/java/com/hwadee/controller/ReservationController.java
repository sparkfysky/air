package com.hwadee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hwadee.entity.Reservation;
import com.hwadee.service.ReservationService;

@Controller
@RequestMapping("/reservation")
public class ReservationController {
	
	@Autowired
	private ReservationService reservationService;
	
	@RequestMapping("/add")
	public String visitAdd() {
		return "reservation/reservation-add"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/reservation_add")
	public String reservationAdd(@Valid Reservation reservationEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("reservationEntity", reservationEntity);
			// 请求转发
			return "reservation/reservation-add";
		} else {
			//调用业务类的方法 
			int flag = reservationService.addReservation(reservationEntity);
			//model.put("userEntity",userEntity);
			return "forward:/reservation/list";
		}
	}
	
	@RequestMapping("/delete")
	public String visitDelete(@Valid Integer reservationid) {

			int flag = reservationService.deleteReservation(reservationid);
			return "forward:/reservation/list";
		}
	
	@RequestMapping("/update")
	public String visitUpdatex() {
		return "reservation/reservation-update"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/reservation_update")
	public String reservationUpdate(@Valid Reservation reservationEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("reservationEntity", reservationEntity);
			// 请求转发
			return "reservation/reservation-update";
		} else {
			//调用业务类的方法 
			int flag = reservationService.updateReservation(reservationEntity);
			return "forward:/reservation/list";
		}
	}
	
	@RequestMapping("/reservation_select")
	public String reservationSelect(@Valid Integer reservationid, Map<String, Reservation> model) {
		// 判断是否有错误
			//调用业务类的方法 
			Reservation reservation = reservationService.getReservationById(reservationid);
			model.put("reservations", reservation);
			return "reservation/reservation-select";
		}
	
	@RequestMapping("/list")
	public String visitlist(@Valid Map<String, List<Reservation>> model) {
	// 判断是否有错误
		//调用业务类的方法 
		List<Reservation> reservationlist = reservationService.getReservationList();
		model.put("reservations", reservationlist);
		return "reservation/reservation-list";
	}
	
}