package com.hwadee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hwadee.entity.Operator;
import com.hwadee.service.OperatorService;


@Controller
@RequestMapping("/admin")
public class OperatorController {
	
	/*
	 * IOC/DI
	 */
	@Autowired
	private  OperatorService operatorService;

	/*
	 * 访问addUser.jsp页面
	 */
//	@RequestMapping("/login")
//	public String visitIndex1() {
//		return "user/index"; // 视图中文件的名称(不带后缀名的)
//	}
	
	/*
	 * 访问addUser.jsp页面
	 */
	@RequestMapping("/add")
	public String visitIndex() {
		return "admin/admin-add"; // 视图中文件的名称(不带后缀名的)
	}
	/*
	 * 添加用户信息
	 */
	@RequestMapping("/admin_add")
	public String saveUser(@Valid Operator userEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("userEntity", userEntity);
			// 请求转发
			return "admin/admin-add";
		} else {
			//调用业务类的方法 
			int flag = operatorService.addOperator(userEntity);
			//model.put("userEntity",userEntity);
			return "forward:/admin/list";
		}
	}
	
	/*
	 * 访问deleteUser.jsp页面
	 */
	

	/*
	 * 删除用户信息
	 */
	@RequestMapping("/delete")
	public String deleteUser(@Valid Integer employeeid) {

			int flag = operatorService.deleteOperator(employeeid);
			return "forward:/admin/list";
		}
	
//	
	/*
	 * 访问updateUser.jsp页面
	 */
	@RequestMapping("/update")
	public String updateIndex() {
		return "admin/admin-update"; // 视图中文件的名称(不带后缀名的)
	}
	/*
//	 * 更新用户信息
//	 */
	@RequestMapping("/admin_update")
	public String updateUser(@Valid Operator userEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("userEntity", userEntity);
			// 请求转发
			return "admin/admin-update";
		} else {
			//调用业务类的方法 
			int flag = operatorService.updateOperator(userEntity);
			return "forward:/admin/list";
		}
	}
//	
//
//	/*
//	 * 查询用户信息界面
//	 */
//	/**
//	 * 查询学生信息
//	 * 
//	 * @param page
//	 * @param model
//	 * @return
//	 */
////	@RequestMapping("/select")
////	public String getSelectStudent(Page<UserHouse> page, Model model) {
////
////		long currentPage = page.getCurrentPage();
////		if (currentPage < 0) {
////			currentPage = 1;
////		}
////
////		Page pagedata = new Page<UserHouse>(page.getPageNum(), currentPage);
////		pagedata.setBlurname(page.getBlurname());
////		// 查询出来的最新的数据
////		pagedata = userService.getPageStudentList(pagedata);
////		model.addAttribute("pagedata", pagedata);
////		return "student/select";
////	}
//	/*
//	 * 查询用户信息操作
//	 */
	@RequestMapping("/admin_select")
	public String selectUser(@Valid Integer employeeid, Map<String, Operator> model) {
		// 判断是否有错误
			//调用业务类的方法 
			Operator operator = operatorService.getOperatorById(employeeid);
			model.put("admins", operator);
			return "admin/admin-select";
		}
	
//	/*
//	 * 查询用户信息操作
//	 */
//	
//	
//		
//	
		@RequestMapping("/list")
		public String selectUser(@Valid Map<String, List<Operator>> model) {
		// 判断是否有错误
			//调用业务类的方法 
			List<Operator> adminlist = operatorService.getOperatorList();
			model.put("admins", adminlist);
			return "admin/admin-list";
		}
		
		@RequestMapping("/welcome")
		public String getIndex() {
			return "admin/welcome";
		}
		
		@RequestMapping("/enterprise")
		public String getAbout() {
			return "qiantai/about";
		}
		@RequestMapping("/news")
		public String getNews() {
			return "qiantai/news";
		}
		@RequestMapping("/business")
		public String getBusiness() {
			return "qiantai/business";
		}
		@RequestMapping("/houtai")
		public String gethoutai() {
			return "houtai";
		}
		
		
		
}