package com.hwadee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hwadee.entity.Resume;
import com.hwadee.service.ResumeService;

@Controller
@RequestMapping("/resume")
public class ResumeController {
	
	@Autowired
	private ResumeService resumeService;
	
	@RequestMapping("/add")
	public String visitAdd() {
		return "resume/resume-add"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/resume_add")
	public String resumeAdd(@Valid Resume resumeEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("resumeEntity", resumeEntity);
			// 请求转发
			return "resume/resume-add";
		} else {
			//调用业务类的方法 
			int flag = resumeService.addResume(resumeEntity);
			//model.put("userEntity",userEntity);
			return "forward:/resume/list";
		}
	}
	
	@RequestMapping("/delete")
	public String visitDelete(@Valid Integer resumeid) {

			int flag = resumeService.deleteResume(resumeid);
			return "forward:/resume/list";
		}
	
	@RequestMapping("/update")
	public String visitUpdatex() {
		return "resume/resume-update"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/resume_update")
	public String resumeUpdate(@Valid Resume resumeEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("resumeEntity", resumeEntity);
			// 请求转发
			return "resume/resume-update";
		} else {
			//调用业务类的方法 
			int flag = resumeService.updateResume(resumeEntity);
			return "forward:/resume/list";
		}
	}
	
	@RequestMapping("/resume_select")
	public String resumeSelect(@Valid Integer resumeid, Map<String, Resume> model) {
		// 判断是否有错误
			//调用业务类的方法 
			Resume resume = resumeService.getResumeById(resumeid);
			model.put("resumes", resume);
			return "resume/resume-select";
		}
	
	@RequestMapping("/list")
	public String visitlist(@Valid Map<String, List<Resume>> model) {
	// 判断是否有错误
		//调用业务类的方法 
		List<Resume> resumelist = resumeService.getResumeList();
		model.put("resumes", resumelist);
		return "resume/resume-list";
	}
	
}