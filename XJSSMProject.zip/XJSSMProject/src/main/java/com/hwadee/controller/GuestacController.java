package com.hwadee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hwadee.entity.Guestac;
import com.hwadee.service.GuestacService;


@Controller
@RequestMapping("/guest")
public class GuestacController {
	
	/*
	 * IOC/DI
	 */
	@Autowired
	private  GuestacService operatorService;

	/*
	 * 访问addUser.jsp页面
	 */
//	@RequestMapping("/login")
//	public String visitIndex1() {
//		return "user/index"; // 视图中文件的名称(不带后缀名的)
//	}
	
	/*
	 * 访问addUser.jsp页面
	 */
	@RequestMapping("/add")
	public String visitIndex() {
		return "guest/guest-add"; // 视图中文件的名称(不带后缀名的)
	}
	/*
	 * 添加用户信息
	 */
	@RequestMapping("/guest_add")
	public String saveUser(@Valid Guestac userEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("userEntity", userEntity);
			// 请求转发
			return "guest/guest-add";
		} else {
			//调用业务类的方法 
			int flag = operatorService.addGuestac(userEntity);
			//model.put("userEntity",userEntity);
			return "forward:/guest/list";
		}
	}
	
	/*
	 * 访问deleteUser.jsp页面
	 */
	

	/*
	 * 删除用户信息
	 */
	@RequestMapping("/delete")
	public String deleteUser(@Valid Integer employeeid) {

			int flag = operatorService.deleteGuestac(employeeid);
			return "forward:/guest/list";
		}
	
//	
	/*
	 * 访问updateUser.jsp页面
	 */
	@RequestMapping("/update")
	public String updateIndex() {
		return "guest/guest-update"; // 视图中文件的名称(不带后缀名的)
	}
	/*
//	 * 更新用户信息
//	 */
	@RequestMapping("/guest_update")
	public String updateUser(@Valid Guestac userEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("userEntity", userEntity);
			// 请求转发
			return "guest/guest-update";
		} else {
			//调用业务类的方法 
			int flag = operatorService.updateGuestac(userEntity);
			return "forward:/guest/list";
		}
	}
//	
//
//	/*
//	 * 查询用户信息界面
//	 */
//	/**
//	 * 查询学生信息
//	 * 
//	 * @param page
//	 * @param model
//	 * @return
//	 */
////	@RequestMapping("/select")
////	public String getSelectStudent(Page<UserHouse> page, Model model) {
////
////		long currentPage = page.getCurrentPage();
////		if (currentPage < 0) {
////			currentPage = 1;
////		}
////
////		Page pagedata = new Page<UserHouse>(page.getPageNum(), currentPage);
////		pagedata.setBlurname(page.getBlurname());
////		// 查询出来的最新的数据
////		pagedata = userService.getPageStudentList(pagedata);
////		model.addAttribute("pagedata", pagedata);
////		return "student/select";
////	}
//	/*
//	 * 查询用户信息操作
//	 */
	@RequestMapping("/guest_select")
	public String selectUser(@Valid Integer employeeid, Map<String, Guestac> model) {
		// 判断是否有错误
			//调用业务类的方法 
			Guestac operator = operatorService.getGuestacById(employeeid);
			model.put("guests", operator);
			return "guest/guest-select";
		}
	
//	/*
//	 * 查询用户信息操作
//	 */
//	
//	
//		
//	
		@RequestMapping("/list")
		public String selectUser(@Valid Map<String, List<Guestac>> model) {
		// 判断是否有错误
			//调用业务类的方法 
			List<Guestac> guestlist = operatorService.getGuestacList();
			model.put("guests", guestlist);
			return "guest/guest-list";
		}
		
		
}