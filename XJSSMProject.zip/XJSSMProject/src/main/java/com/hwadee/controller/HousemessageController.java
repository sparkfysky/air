package com.hwadee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hwadee.entity.Housemessage;
import com.hwadee.service.HousemessageService;

@Controller
@RequestMapping("/message")
public class HousemessageController {
	
	@Autowired
	private HousemessageService housemessageService;
	
	@RequestMapping("/add")
	public String visitAdd() {
		return "message/message-add"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/message_add")
	public String messageAdd(@Valid Housemessage messageEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("messageEntity", messageEntity);
			// 请求转发
			return "message/message-add";
		} else {
			//调用业务类的方法 
			int flag = housemessageService.addHousemessage(messageEntity);
			//model.put("userEntity",userEntity);
			return "forward:/message/list";
		}
	}
	
	@RequestMapping("/delete")
	public String visitDelete(@Valid Integer messageid) {

			int flag = housemessageService.deleteHousemessage(messageid);
			return "forward:/message/list";
		}
	
	@RequestMapping("/update")
	public String visitUpdatex() {
		return "message/message-update"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/message_update")
	public String messageUpdate(@Valid Housemessage messageEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("messageEntity", messageEntity);
			// 请求转发
			return "message/message-update";
		} else {
			//调用业务类的方法 
			int flag = housemessageService.updateHousemessage(messageEntity);
			return "forward:/message/list";
		}
	}
	
	@RequestMapping("/message_select")
	public String messageSelect(@Valid Integer messageid, Map<String, Housemessage> model) {
		// 判断是否有错误
			//调用业务类的方法 
			Housemessage housemessage = housemessageService.getHousemessageById(messageid);
			model.put("messages", housemessage);
			return "message/message-select";
		}
	
	@RequestMapping("/list")
	public String visitlist(@Valid Map<String, List<Housemessage>> model) {
	// 判断是否有错误
		//调用业务类的方法 
		List<Housemessage> messagelist = housemessageService.getHousemessageList();
		model.put("messages", messagelist);
		return "message/message-list";
	}
	
}