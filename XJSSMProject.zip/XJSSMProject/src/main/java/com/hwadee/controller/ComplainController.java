package com.hwadee.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hwadee.entity.Complain;
import com.hwadee.service.ComplainService;

@Controller
@RequestMapping("/complain")
public class ComplainController {
	
	@Autowired
	private ComplainService complainService;
	
	@RequestMapping("/add")
	public String visitAdd() {
		return "complain/complain-add"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/complain_add")
	public String complainAdd(@Valid Complain complainEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("complainEntity", complainEntity);
			// 请求转发
			return "complain/complain-add";
		} else {
			//调用业务类的方法 
			int flag = complainService.addComplain(complainEntity);
			//model.put("userEntity",userEntity);
			return "forward:/complain/list";
		}
	}
	
	@RequestMapping("/delete")
	public String visitDelete(@Valid Integer complainid) {

			int flag = complainService.deleteComplain(complainid);
			return "forward:/complain/list";
		}
	
	@RequestMapping("/update")
	public String visitUpdatex() {
		return "complain/complain-update"; // 视图中文件的名称(不带后缀名的)
	}
	
	@RequestMapping("/complain_update")
	public String complainUpdate(@Valid Complain complainEntity, BindingResult result, Model model) {
		// 判断是否有错误
		if (result.hasErrors()) {
			// 如果没有通过,跳转提示
			List<FieldError> fieldErrors = result.getFieldErrors();
			for (FieldError fieldError : fieldErrors) {
				System.out.println("error_" + fieldError.getField() + "   " + fieldError.getDefaultMessage());
				model.addAttribute("error_" + fieldError.getField(), fieldError.getDefaultMessage());
			}
			model.addAttribute("complainEntity", complainEntity);
			// 请求转发
			return "complain/complain-update";
		} else {
			//调用业务类的方法 
			int flag = complainService.updateComplain(complainEntity);
			return "forward:/complain/list";
		}
	}
	
	@RequestMapping("/complain_select")
	public String complainSelect(@Valid Integer complainid, Map<String, Complain> model) {
		// 判断是否有错误
			//调用业务类的方法 
			Complain complain = complainService.getComplainById(complainid);
			model.put("complains", complain);
			return "complain/complain-select";
		}
	
	@RequestMapping("/list")
	public String visitlist(@Valid Map<String, List<Complain>> model) {
	// 判断是否有错误
		//调用业务类的方法 
		List<Complain> complainlist = complainService.getComplainList();
		model.put("complains", complainlist);
		return "complain/complain-list";
	}
	
}