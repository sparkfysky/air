#include <iostream>
#include <string.h>
#include <stdio.h>
using namespace std;
#define Max_size 100
#define input_string_max_size 5000

class maze{
private :
        int big_map[Max_size*2+1][Max_size*2+1];
        int row, col,countnum;
        bool flag,finish;
        //big_map the maze
        //row and column to get the maze row and column;countnum to record the finite automaton'state(i use a finite automaton to judge input format)
        //flag to record whether the input is success;finish to judge whether the "enter" is code in advance(using to judge the input format)
public  :
        bool check_initial(string s){
                char*p =new char[input_string_max_size];
                strcpy(p,s.c_str());
                int i=0;
                for(;p[i]!='\n';i++){
                        switch(countnum){
                                case 0:{
                                        if((p[i]>='0'&&p[i]<='9')||p[i]=='-'||p[i]==' '||p[i]=='\t'){
                                        //whether transform to a number
                                                if((p[i]>='0'&&p[i]<='9')||p[i]=='-'){
                                                //whether input '\t' or ' ' to judge command format
                                                        if(p[i]>='0'&&p[i]<='9'){
                                                        //row and column can not be negative number
                                                                row=row*10+(p[i]-'0');
                                                                if(p[i+1]>'9'||p[i+1]<'0')
                                                                        countnum++;
                                                        }
                                                        else{
                                                                printf("”Number out of range.”");
                                                                return false;
                                                        }
                                                }
                                                else{
                                                        printf("”Incorrect command format.”");
                                                        return false;
                                                }
                                        }
                                        else{
                                                printf("”Invalid number format.”");
                                                return false;
                                        }
                                        continue;
                                }
                                case 1:{
                                        if(p[i]!=' '){
                                                printf("”Incorrect command format.”");
                                                return false;
                                        }
                                        countnum++;
                                        continue;
                                }
                                case 2:{
                                        if((p[i]>='0'&&p[i]<='9')||p[i]=='-'){
                                                if(p[i]>='0'&&p[i]<='9'){
                                                        col=col*10+(p[i]-'0');
                                                        if(p[i+1]>'9'||p[i+1]<'0')
                                                                countnum++;
                                                }
                                                else{
                                                        printf("”Number out of range.”");
                                                        return false;
                                                }
                                        }
                                        else{
                                                printf("”Invalid number format.”");
                                                return false;
                                        }
                                        continue;
                                }
                                case 3:{
                                        printf("”Incorrect command format.”");
                                        return false;
                                }
                        }
                }
                //read the row and col while judging the form problem
                //make every input as a state and use finite automaton to judge format
                if(countnum!=3){
                        printf("”Incorrect command format.”");
                        return false;
                }

                countnum=0;
                int temp_row1=0;
                int temp_col1=0;
                int temp_row2=0;
                int temp_col2=0;
                for(i=i+1;p[i]!='\0';i++){
                        switch(countnum){
                                case 0:{
                                        if((p[i]>='0'&&p[i]<='9')||p[i]=='-'||p[i]==' '||p[i]=='\t'){
                                                if((p[i]>='0'&&p[i]<='9')||p[i]=='-'){
                                                        if(p[i]>='0'&&p[i]<='9'){
                                                                temp_row1=temp_row1*10+(p[i]-'0');
                                                                if(p[i+1]>'9'||p[i+1]<'0')
                                                                        countnum++;
                                                        }
                                                        else{
                                                                printf("”Number out of range.”");
                                                                return false;
                                                        }
                                                }
                                                else{
                                                        printf("”Incorrect command format.”");
                                                        return false;
                                                }
                                        }
                                        else{
                                                printf("”Invalid number format.”");
                                                return false;
                                        }
                                        continue;
                                }
                                case 1:{
                                        if(p[i]!=','){
                                                printf("”Incorrect command format.”");
                                                return false;
                                        }
                                        countnum++;
                                        continue;
                                }
                                case 2:{
                                        if((p[i]>='0'&&p[i]<='9')||p[i]=='-'){
                                                if(p[i]>='0'&&p[i]<='9'){
                                                        temp_col1=temp_col1*10+(p[i]-'0');
                                                        if(p[i+1]>'9'||p[i+1]<'0'){
                                                                if(temp_col1<col&&temp_row1<row)
                                                                //index can not over row or column
                                                                        big_map[2*temp_row1+1][2*temp_col1+1]=1;
                                                                else{
                                                                        printf("”Number out of range.”");
                                                                        return false;
                                                                }
                                                                countnum++;
                                                        }
                                                }
                                                else{
                                                        printf("”Number out of range.”");
                                                        return false;
                                                }
                                        }
                                        else{
                                                printf("”Invalid number format.”");
                                                return false;
                                        }
                                        continue;
                                }
                                case 3:{
                                        if(p[i]!=' '){
                                                printf("”Incorrect command format.”");
                                                return false;
                                        }
                                        countnum++;
                                        continue;
                                }
                                case 4:{
                                        if((p[i]>='0'&&p[i]<='9')||p[i]=='-'){
                                                if(p[i]>='0'&&p[i]<='9'){
                                                        temp_row2=temp_row2*10+(p[i]-'0');
                                                        if(p[i+1]>'9'||p[i+1]<'0')
                                                                countnum++;
                                                }
                                                else{
                                                        printf("”Number out of range.”");
                                                        return false;
                                                }
                                        }
                                        else{
                                                printf("”Invalid number format.”");
                                                return false;
                                        }
                                        continue;
                                }
                                case 5:{
                                        if(p[i]!=','){
                                                printf("”Incorrect command format.”");
                                                return false;
                                        }
                                        countnum++;
                                        continue;
                                }
                                case 6:{
                                        if((p[i]>='0'&&p[i]<='9')||p[i]=='-'){
                                                if(p[i]>='0'&&p[i]<='9'){
                                                        temp_col2=temp_col2*10+(p[i]-'0');
                                                        if(p[i+1]>'9'||p[i+1]<'0'){
                                                                if(temp_col2<col&&temp_row2<row){
                                                                        big_map[2*temp_row2+1][2*temp_col2+1]=1;
                                                                        if(temp_row1==temp_row2||temp_col1==temp_col2){
                                                                        // connect the maze,and initialise the temp row and column
                                                                                if(temp_row1==temp_row2&&temp_col1<temp_col2)
                                                                                        big_map[2*temp_row1+1][2*temp_col1+2]=1;
                                                                                if(temp_row1==temp_row2&&temp_col1>temp_col2)
                                                                                        big_map[2*temp_row1+1][2*temp_col2+2]=1;
                                                                                if(temp_row1<temp_row2&&temp_col1==temp_col2)
                                                                                        big_map[2*temp_row1+2][2*temp_col1+1]=1;
                                                                                if(temp_row1>temp_row2&&temp_col1==temp_col2)
                                                                                        big_map[2*temp_row2+2][2*temp_col1+1]=1;
                                                                                temp_row1=0;
                                                                                temp_row2=0;
                                                                                temp_col1=0;
                                                                                temp_col2=0;
                                                                        }
                                                                        else{
                                                                                printf("”Maze format error.”");
                                                                                return false;
                                                                                }
                                                                }
                                                                else{
                                                                        printf("”Number out of range.”");
                                                                        return false;
                                                                }
                                                                countnum++;
                                                                }
                                                        if(p[i+1]=='\0')
                                                        //whether finish the code
                                                                finish=1;
                                                }
                                                else{
                                                        printf("”Number out of range.”");
                                                        return false;
                                                }
                                        }
                                        else{
                                                printf("”Invalid number format.”");
                                                return false;
                                        }
                                        continue;
                                }
                                case 7:{
                                        if(p[i]!=';'){
                                                printf("”Incorrect command format.”");
                                                return false;
                                        }
                                        countnum=0;
                                        //initial the state machine
                                        continue;
                                }
                        }
                }
                if(!finish){
                        printf("”Incorrect command format.”");
                        return false;
                }
                return true;
        }
        //check and make the maze
        // bool check(string s){return true;}
        maze(string s){
                memset(big_map,0,sizeof(big_map));
                row=0;
                col=0;
                countnum=0;
                flag=0;
                finish=0;
                if(check_initial(s))
                flag=1;
        }
        void print(){
                if(flag==1){
                        for(int i=0;i<row*2+1;i++){
                                for(int j=0;j<col*2+1;j++){
                                        if(big_map[i][j]==0)
                                                printf("[W] ");
                                        else
                                                printf("[R] ");
                                }
                                printf("\n");
                        }
                }
                else
                        return;
        }
        //print the maze
};
int main()
{
        string command1;
        string command2;
        getline(cin,command1);
        getline(cin,command2);
        string link="\n";
        command1=command1+link;
        command1=command1+command2;
        //"2 2\n0,0 0,1";3 3\n0,1 0,2;0,0 1,0;0,1 1,1;0,2 1,2;1,0 1,1;1,1 1,2;1,1 2,1;1,2 2,2;2,0 2,1
        //initial the input for the input'/n',i connenect 3 string
        maze test(command1);
        test.print();
        return 0;
}

